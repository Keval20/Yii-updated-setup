<?php

/**
 * Created by PhpStorm.
 * User: rohan
 * Date: 11/23/2015
 * Time: 5:10 AM
 */
$local = true;

//BASE URL
$host = $_SERVER['SERVER_NAME'];

define("DEFAULT_IMAGE","/backend/web/uploads/users/default_image.png");

define("ADMIN_LOGO", "/backend/web/logo.png");
//define("ADMIN_LOGO", "/backend/web/logo.jpg");
define("SIDE_LOGO", "/backend/web/images/logo.png");
define("SIDE_LOGO_MINI", "/backend/web/images/main-logo.png");

//APP INFO
define("APP_NAME", "Trunkit");
define("VERSION", "1.0.0");
define("COMPANY_NAME", "XcelTec");
define('ADMIN_EMAIL', 'demo.xceltec@gmail.com');

define("FROM_EMAIL", "demo.xceltec4@gmail.com");

//Status
define("ACTIVE", 'Y');
define("INACTIVE", 'N');
define("PENDING", 'P');

//define("FINISHED",2);
//set password
define("DEFAULT_PASSWORD", '123456');

define("ENV", "sandbox");
define("MERCHANT_ID", "j633bjpsmj25sq6p");
define("PUBLIC_KEY", "tvjy6jwpfdv43v32");
define("PRIVATE_KEY", "9fe98b3a8365b0db615806db30f3ec66");

//Deleted
define("DELETED", 'Y');
define("NOT_DELETED", 'N');

//platforms
define("WEB", 0);
define("IOS", 1);
define("ANDROID", 2);


//send mail types constants
define('WELCOME_MAIL', 1);
define('FORGOT_PASSWORD_MAIL', 2);

// Roles
define("ADMIN", 1);
//define("SUPER_ADMIN", 2);
//define("APP_USER", 3);

//User's Verification Status
define("USER_VERIFIED", 1);
define("USER_PENDING", 0);

//some Default values
define("DEFAULT_COUNTRY_CODE", 91);
define("DEFAULT_USER_ID", 1);

//Login Status
define("NOT_LOGGED_IN", 0);
define("LOGGED_IN", 1);

//DEFUALT VALUES


define('PAGESIZE', 10);
define('DONATION_PAGESIZE', 30);


define("REST_DEFAULT_MESSAGE_STRING", "oops... there is some problem in code, edison.. you can do it and we know that");
define("DEFAULT_MESSAGE_STRING", "oops... there is some problem in code, edison.. you can do it and we know that");

//messages in flash
define('ADDED', ' has been added successfully.');
define('UPDATED', ' has been updated successfully.');
define('DEACTIVATED', ' has been deactivated successfully.');
define('ACTIVATED', ' has been activated successfully.');
define('APPROVED', ' has been approved successfully.');
define('NOTAPPROVED', ' has not been approved.');
define('PENDINGDONE', ' Pending status done successfully.');
define('DELETEDMESSAGE', ' has been deleted successfully.');
define('EMAIL', 'This email is already exist.');
define('LICENCE', 'This licence number is already exist.');
define('NAME', 'This name is already exist.');
define('RESTAURANTNAME', 'This Restaurant Name is already exist.');
define('PAGEID', 'This Page Id is already exist.');
define('PAGENAME', 'This Page Name is already exist.');
define('NINO', 'This NINO is already exist.');
define('ALREADY', ' is already exist.');
define('ACTIVESTATUS', ' Are you sure want to active this');
define('INACTIVESTATUS', ' Are you sure want to inactive this');
define('APPROVESTATUS', ' Are you sure want to approve this');
define('NOTAPPROVEDSTATUS', ' Are you sure you do not want to approve this');
define('PENDINGSTATUS', ' Are you sure want to pending this');
define('DELETESTATUS', ' Are you sure want to delete this');
define('DATA_NOT_SAVED', 'Something Error: In data save!');
define('PHONE', 'This contact number is already exist.');
define('PHONEPLUSONE', 'Contact number must start with "+1"');
define('PAYPAL', 'This paypal email is already exist.');
define('PLATE', 'This plate number is already exist.');
//push-notification 
define('SERVER_API_KEY', 'AAAA4IeDtF0:APA91bEB-rhez0SwrZnsAy-vst5yst2OKFvooE-g-Of2ZupvfEEo5JMMEZMqpsusQwd_IDwJmK2KUILdg0MJbJZWrBQrUCG-UDfW5_Iqs4tU138uBvwMI1VHJ7IE_VxaPuQAExYgTyVg');
define('DEVICE_TOKEN', 'APA91bF1IH1kg81FUc6shepA_4BQXHQ5gPT2VTNfnCgzzgR61fU3L3M_Vr1UomkCJVCpWY4ZiM3HXC_J6AboxgaZuQms-rj7QQcoxcqrdM9Kxcj0cUN3nkAVNtmSTZKdyG0RVH8cBagSb7LvgSSRHZ1060sSY1aXBg');

define('GOOGLE_CLIENT_ID', '353751721387-0ivhagk89dvbp9rv0rkh15ma3tdhomee.apps.googleusercontent.com');
define('GOOGLE_SECRET_KEY', 'bGgC28ttqjmNJSXxpwVQhiJQ');
define('DATA_NOT_VALID', 'Something Error: Invalid data!');

//define('FACEBOOK_APP_ID', '228032454374464');
//define('FACEBOOK_APP_SECRET', '8256696e07d8e85459840e752581b07b');

define('FACEBOOK_APP_ID', '611136312428492');
define('FACEBOOK_APP_SECRET', '6d6d1daff6c7b6d8c8765e2ef67e2ca6');

define("YES", 'Y');
define("NO", 'N');

//define('TWILIO_SID', 'AC5ecef1a195ba31ba0b0a97c3e2317c2b'); //our test account
define('TWILIO_SID', 'ACefb6fe697450d162f9f3b72dcc7ec02f');
//define('TWILIO_TOKEN', '01df6acad60ab947f04ff01d51795980'); //our test account
define('TWILIO_TOKEN', '98d2ecb4a5e43f359193c1312dca8899');
define('ACCEPT', 'ACCEPT');
define('DECLINED', 'DECLINED');
define('PAID','PAID');
define('COMPLETED','COMPLETED');
define('USER_PROFILE_PATH', '/media/users/image/');
define('USER_LICENCE_PATH', '/media/users/driver_licence/');
define('USER_CAR_INS_PATH', '/media/insurance/');
define('USER_VEHICLE_PATH', '/media/vehicles/');
define('USER_POST_TRIP_PATH', '/media/post-trip/');
define('USER_REQUEST_IMAGE1_PATH', '/media/post-request/item_1/');
define('USER_REQUEST_IMAGE2_PATH', '/media/post-request/item_2/');
define('LOGO_PATH', '/media/images/');
define('PLATE_NO', 'This Plate Number is already exist.');
define("SEEN", 'Y');
define("UNSEEN", 'N');